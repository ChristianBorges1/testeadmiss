<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'Colaborador') {
    header('Location: login.php');
    exit();
}

// Processamento do formulário de resposta de chamados
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ticket_id = $_POST['ticket_id'];
    $response = $_POST['response'];
    header('Location: success.php');
    exit();
}
?>
