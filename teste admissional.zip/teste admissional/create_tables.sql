-- Tabela de usuários
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    cpf VARCHAR(14) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    user_type ENUM('Cliente', 'Colaborador') NOT NULL
);

-- Tabela de chamados
CREATE TABLE tickets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    attachment VARCHAR(255),
    status ENUM('Aberto', 'Em atendimento', 'Finalizado') NOT NULL DEFAULT 'Aberto',
    FOREIGN KEY (user_id) REFERENCES users(id)
);
