<?php
// Processamento do formulário de cadastro
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Captura os dados do formulário
    $full_name = $_POST['full_name'];
    $cpf = $_POST['cpf'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $user_type = $_POST['user_type'];
    
    // Insere o usuário no banco de dados (implementação não fornecida)
    // Redireciona para a página de login
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro</title>
</head>
<body>
    <h1>Cadastro</h1>
    <form action="register.php" method="post">
        <label for="full_name">Nome Completo:</label><br>
        <input type="text" id="full_name" name="full_name" required><br>
        <label for="cpf">CPF:</label><br>
        <input type="text" id="cpf" name="cpf" required><br>
        <label for="email">E-mail:</label><br>
        <input type="email" id="email" name="email" required><br>
        <label for="password">Senha:</label><br>
        <input type="password" id="password" name="password" required><br>
        <label for="user_type">Tipo de Usuário:</label><br>
        <select id="user_type" name="user_type" required>
            <option value="Cliente">Cliente</option>
            <option value="Colaborador">Colaborador</option>
        </select><br>
        <input type="submit" value="Cadastrar">
    </form>
</body>
</html>
