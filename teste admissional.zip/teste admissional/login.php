<?php
session_start();

// Processamento do formulário de login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verifica os dados do formulário (implementação não fornecida)
    // Autentica o usuário (implementação não fornecida)
    // Redireciona para a página de abertura de chamados
    header('Location: open_ticket.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <h1>Login</h1>
    <form action="login.php" method="post">
        <label for="email">E-mail:</label><br>
        <input type="email" id="email" name="email" required><br>
        <label for="password">Senha:</label><br>
        <input type="password" id="password" name="password" required><br>
        <input type="submit" value="Login">
    </form>
</body>
</html>
