<?php
session_start();

// Verifica se o usuário está logado e se é um cliente
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'Cliente') {
    header('Location: login.php');
    exit();
}

// Processamento do formulário de abertura de chamados
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Captura os dados do formulário
    $title = $_POST['title'];
    $description = $_POST['description'];
    // Salva o chamado no banco de dados (implementação não fornecida)
    // Envia e-mail para os colaboradores (implementação não fornecida)
    // Redireciona para a página de sucesso
    header('Location: success.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Abrir Chamado</title>
</head>
<body>
    <h1>Abrir Chamado</h1>
    <form action="open_ticket.php" method="post">
        <label for="title">Título:</label><br>
        <input type="text" id="title" name="title" required><br>
        <label for="description">Descrição:</label><br>
        <textarea id="description" name="description" required></textarea><br>
        <input type="submit" value="Abrir Chamado">
    </form>
</body>
</html>
